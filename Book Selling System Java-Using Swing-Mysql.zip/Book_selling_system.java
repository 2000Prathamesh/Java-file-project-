package Textbook_selling_system;

/**
 * 
 * @author Soumyadip Chowdhury
 * @github soumyadip007
 *
 */

public class Book_selling_system {


	public static void main(String args[])
	{
		Main_screen ms=new Main_screen();
		ms.setTitle("Book Hub");
		ms.setVisible(true);
	}
}
